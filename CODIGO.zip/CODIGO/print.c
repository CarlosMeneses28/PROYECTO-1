/* Ruler 1         2         3         4         5         6         7        */

/********************************  print.c  ***********************************/
/*                                                                            */
/*   Purpose: Print matrixs, vectors and PageRank´s vector                    */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

/********************************** Headers ***********************************/

/* ------------------------ Inclusion of Std Headers ------------------------ */

#include <stdio.h>

/* ----------------------- Inclusion of Other Headers ----------------------- */

#include "print.h"

/*****************************  Public Functions  *****************************/

/*FN****************************************************************************
*
*   int 
*   printOriginalMatrix (double matrix [N][N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Prints the original matrix
*
*   Plan:
*           Part 1: Print the matrix value with index i,j (without decimals)
*
*******************************************************************************/

int 
printOriginalMatrix (double matrix [N][N])
{
  for (int i = 0; i < N; i++) {
      for (int j = 0; j < N; j++) {

          //Part 1
          printf("%0.0f\t", matrix[i][j]);
        
      }
      printf("\n");
  }
  return 1;
}

/*FN****************************************************************************
*
*   int 
*   printMatrix (double matrix [N][N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Prints a matrix
*
*   Plan:
*           Part 1: Print the matrix value with index i,j (with two decimals)
*
*******************************************************************************/

int printMatrix (double matrix [N][N])
{
  for (int i = 0; i < N; i++) {
      for (int j = 0; j < N; j++) {
        
          //Part 1
          printf("%0.2f\t", matrix[i][j]);
        
      }
      printf("\n");
  }
  return 1;
}

/*FN****************************************************************************
*
*   int 
*   printVector (double vector [N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Prints a vector
*
*   Plan:
*           Part 1: Print the vector value with index i (with six decimals)
*
*******************************************************************************/

int printVector(double vector[N]) {
  
    for (int i = 0; i < N; i++) {
      int j=i+1;

      //Part 1
      if (j == 10)
        printf("%d| ",j);
      else
        printf("%d | ",j);
        printf("%0.6f\n",vector[i]);
    }
  
  printf("\n");
  return 1;
}

/*FN****************************************************************************
*
*   int 
*   printRanking (double vector_PageRank [N][2])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Prints the PageRank´s vector
*
*   Plan:
*           Part 1: Print the PageRank´s vector value with index i 
*                   (with six decimals)
*
*******************************************************************************/

int printRanking (double vector_PageRank[N][2])
{
  for (int i =0; i<10;i++){
    
    //Part 1
    if(vector_PageRank[i][0]>999)
      printf("%0.0f | %f\n", vector_PageRank[i][0], vector_PageRank[i][1]);
    else{
      if(vector_PageRank[i][0]>99 && vector_PageRank[i][0]<1000)
        printf("%0.0f  | %f\n", vector_PageRank[i][0], vector_PageRank[i][1]);
      else
        printf("%0.0f   | %f\n", vector_PageRank[i][0], vector_PageRank[i][1]);
    }
  }
  return 1;
}