/* Ruler 1         2         3         4         5         6         7        */

/*****************************  powerMethod.h  ********************************/
/*                                                                            */
/*   Purpose: Power Method                                          */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

#ifndef POWERMETHOD_H
#define POWERMETHOD_H
#define N 3444

/************************** Prototypes of Functions ***************************/

double euclidianDistance (double vector [N], double vectorM [N]);
int comparate (double s);
int powerMethod (double matrix[N][N], double vector_iterador [N]);

#endif /* POWERMETHOD_H */