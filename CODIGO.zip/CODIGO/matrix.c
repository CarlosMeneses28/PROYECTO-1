/* Ruler 1         2         3         4         5         6         7        */

/*********************************  matrix.c  *********************************/
/*                                                                            */
/*   Purpose: Construction of matrix                                          */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

/********************************** Headers ***********************************/

/* ---------------------- Constants to Execute Functions ----------------------- */

#define alpha 0.85

/* ------------------------ Inclusion of Std Headers ------------------------ */

#include <stdio.h>
#include <stdlib.h>

/* ----------------------- Inclusion of Other Headers ----------------------- */

#include "matrix.h"

/* ----------------------- Inclusion of Own Headers ----------------------- */

#include "operations.h"

/********************** Prototypes of Private Functions ***********************/

double sumV (double vector[]);

/*****************************  Public Functions  *****************************/

/*FN****************************************************************************
*
*   int 
*   readArchive (double matrix [N][N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Reads the file and enters de data into the matrix
*
*   Plan:
*           Part 1: Open the file
*           Part 2: If the Part 1 fails return 0
*           Part 3: Input the data into the matrix
*           Part 4: Close the file
*
*******************************************************************************/

int 
readArchive (double matrix [N][N])
{
    FILE *file;
    double value;

   //Part 1
    file = fopen("matriz_adyacencia.txt", "r");

    //Part 2
    if (file == NULL) {
        perror("Error opening the file");
        return 0;
    }

    for (int i = 0; i < N; i++) {
        for (int j = 0; j < N; j++) {
            if (fscanf(file, "%lf", &value) == 1) {

                //Part 3
                matrix[i][j] = value;
            }
        }
        printf("\n");
    }

    //Part 4
    fclose(file);
    return 1;
}

/*FN****************************************************************************
*
*   double* 
*   prob (double matrix[N][N])
*
*   Return:          Array of values
*
*   Purpose:         Analyze the probability value for each value of each row 
*                    of the matrix
*
*   Plan:
*           Part 1: Inicialize the array
*           Part 2: If the sum of all the values i different to cero, divide 
*                   by the total of the row
*
*******************************************************************************/

double* 
prob (double matrix[N][N])
{
   //Part 1
   double* prob = malloc(N * sizeof(double));

   for (int i = 0; i < N; i++) {
       double sum = sumV(matrix[i]);
     
       //Part 2
       prob[i] = (sum != 0) ? 1.0 / sum : 0;
   }
   return prob;
}

/*FN****************************************************************************
*
*   int 
*   distProb (double matrix[N][N], double prob[N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Replace the probability value for each row of the matrix
*
*   Plan:
*           Part 1: Replace the probability value
*
*******************************************************************************/

int 
distProb (double matrix[N][N], double prob[N])
{
  for (int i = 0; i < N; i++)
    {
      for (int j = 0; j < N; j++)
        {
          //Part 1
          if (matrix[i][j] != 0)
            matrix[i][j] = prob[i];
        }
    }
  return 1;
}

/*FN****************************************************************************
*
*   int 
*   absorbentNode (double matrix[N][N])
*
*   Return:          Number of absorbents nodes in the matrix
*
*   Purpose:         Count the number of absorbent nodes in the matrix

*   Plan:
*           Part 1: Iitialize the counter
*           Part 2: If the value of the sum row is cero, add 1 to the counter
*
*******************************************************************************/

int 
absorbentNode (double matrix[N][N])
{
  //Part 1
  int absorbent = 0;
  for(int i=0; i<N; i++)
    {
      //Part 2
      if (sumV(matrix[i])==0)
      absorbent +=1;
    }
  return absorbent;
}

/*FN****************************************************************************
*
*   int 
*   estochasticMatrix(double matrix[N][N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Coverts the matrix into a stchastic matrix
*
*   Plan:
*           Part 1: Check for absorbing nodes
*           Part 2: If the sum of the values of the row is equal to cero, 
*                   asigns uniform probablity to all the values of the row.
*
*******************************************************************************/

int 
stochasticMatrix(double matrix[N][N]) {
  
  for (int i = 0; i < N; i++) {

    //Part 1
    int sum = sumV(matrix[i]);

      for (int j = 0; j < N; j++) {
          sum += matrix[i][j];
      }
    
      //Part 2
      if (sum == 0) {
          for (int j = 0; j < N; j++) {
              matrix[i][j] = 1.0 / N;
          }
      } 
  }
  return 1;
}

/*FN****************************************************************************
*
*   int 
*   irreducibleMatrix (double matrix[N][N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Coverts the stochastic matrix into a irreducible matrix

*   Plan:
*           Part 1: Replace each value of the matrix 
*
*******************************************************************************/

int 
irreducibleMatrix (double matrix[N][N])
{
  
  for(int i = 0; i < N; i++) {
    for(int j = 0; j < N; j++) {
      
        //Part 1
        matrix[i][j] = (alpha * matrix[i][j]) + ((1 - alpha) / N);
    }
  }
  
  return 1;
}

/*FN****************************************************************************
*
*   int
*   bubbleTranspose (double matrix[N][N],int i, int j)
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Bubble to make the transposed matrix
*
*   Plan:
*           Part 1: Initialize a temporal variable
*           Part 2: Swaap the values of the matrix
*
*******************************************************************************/

int
bubbleTranspose (double matrix[N][N],int i, int j)
{
  //Part 1
  double tmp;

  //Part 2
  tmp = matrix[i][j];
  matrix[i][j] = matrix[j][i];
  matrix[j][i] = tmp;
  
  return 1;
}

/*FN****************************************************************************
*
*   int 
*   transposeMatrix (double matrix[N][N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Make the transposed matrix
*
*   Plan:
*           Part 1: Swap the values of the matrix calling bubbleTranspose 
*                   function
*
*******************************************************************************/

int 
transposeMatrix (double matrix[N][N])
{
  for (int i = 0; i < N; i++)
    {
      for (int j = i; j < N; j++)
        {
          //Part 1
          bubbleTranspose(matrix, i, j);
        }
    }
  return 1;
}