/* Ruler 1         2         3         4         5         6         7        */

/*******************************  operations.h  *******************************/
/*                                                                            */
/*   Purpose: Do useful math operations for vector PageRank                   */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

#ifndef OPERATIONS_H
#define OPERATIONS_H
#define N 3444

/************************** Prototypes of Functions ***************************/

int Mxv(double matrix[N][N], double vector[N]);
double sumV (double vector[]);

#endif /*operationes.h*/ 