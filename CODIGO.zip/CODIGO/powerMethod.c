/* Ruler 1         2         3         4         5         6         7        */

/*****************************  powerMethod.c  ********************************/
/*                                                                            */
/*   Purpose: Power Method                                                    */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

/********************************** Headers ***********************************/

/* ---------------------- Constants to Execute Functions ----------------------- */

#define epsilon 0.001

/* ------------------------ Inclusion of Std Headers ------------------------ */

#include <stdio.h>
#include <math.h>
#include <stdlib.h>

/* ----------------------- Inclusion of Other Headers ----------------------- */

#include "powerMethod.h"

/* ----------------------- Inclusion of Own Headers ----------------------- */

#include "operations.h"

/********************** Prototypes of Private Functions ***********************/

double sumV (double vector[]);

/*****************************  Public Functions  *****************************/

/*FN****************************************************************************
*
*   double 
*   euclidianDistance (double vector_iterador [N], double vectorM [N])
*
*   Return:          Euclidian distance between two vectors
*
*   Purpose:         Determine the euclidian distance between two vectors
*
*   Plan:
*           Part 1: Initialize the vector
*           Part 2: Determine the euclidian distance between the two points
*           Part 3: Determine the euclidian distance between the two vectors
*
*******************************************************************************/

double 
euclidianDistance (double vector_iterador [N], double vectorM [N])
{
  //Part 1
  double vectorN[N];
  
  for (int i=0; i<N; i++){

    //Part 2
    vectorN[i] = pow (vectorM[i] - vector_iterador[i],2);
  }

  //Part 3
  return sqrt(sumV (vectorN));
}

/*FN****************************************************************************
*
*   int 
*   comparate (double s)
*
*   Return:          Number "1" if s is greater than epsilon
*
*   Purpose:         Compare the value of s with the value of epsilon
*
*   Plan:
*           Part 1: Compare the value of s with the value of epsilon
*
*******************************************************************************/

int 
comparate (double s)
{
  int flag;

  //Part 1
  if (s > epsilon)
    flag = 0;
  else 
    flag = 1;
  
  return flag;
}

/*FN****************************************************************************
*
*   int 
*   powerMethod (double matrix[N][N], double vector_iterador [N])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Execute the power method

*   Plan:
*           Part 1: Initialize the vector at 1/N
*           Part 2: While s > epsilon continue to calculate s
*           Part 3: Print the euclidian distance
*
*******************************************************************************/

int 
powerMethod (double matrix[N][N], double vector_iterador [N])
{
  //Part 1
  double vectorM[N];
  for (int i = 0; i < N; i++) {
      vectorM[i] = 1.0 / N;
  }
  Mxv(matrix, vectorM);
  memcpy(vector_iterador, vectorM, N * sizeof(double));
  int flag = 0;
  double s=1000;

  //Part 2
  while (flag == 0)
    {
      memcpy(vectorM,vector_iterador, N * sizeof(double));
      Mxv(matrix, vector_iterador);
      s = euclidianDistance(vector_iterador, vectorM);
      flag = comparate (s);
    }

  //Part 3
  printf ("\n\n\nEuclidian distance:");
  printf("%0.9f\n", s);
  return 1;
}
