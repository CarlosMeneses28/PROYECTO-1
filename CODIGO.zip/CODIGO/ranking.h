/* Ruler 1         2         3         4         5         6         7        */

/******************************  ranking.h  ***********************************/
/*                                                                            */
/*   Purpose: Construction of ranking                                         */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

#ifndef RANKING_H
#define RANKING_H
#define N 3444

/************************** Prototypes of Functions ***************************/

int bubbleRanking (double vector_PageRank[N][2], int i, int j);
int ranking (double vector_iterador [N], double vector_PageRank [N][2]);

#endif /* RANKING_H */