/* Ruler 1         2         3         4         5         6         7        */

/*******************************  pageRank.h  *********************************/
/*                                                                            */
/*   Purpose: The function who calls all the functions                        */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

#ifndef PAGERANK_H
#define PAGERANK_H
#define N 3444

/************************** Prototypes of Functions ***************************/

int PageRank(double matrix[N][N], double vector_iterador[N], double vector_PageRank [N][2]);

#endif /* PRINT_H */