/* Ruler 1         2         3         4         5         6         7        */

/*******************************  print.h  ************************************/
/*                                                                            */
/*   Purpose: Print matrixs, vectors and PageRank´s vector                    */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

#ifndef PRINT_H
#define PRINT_H
#define N 3444

/************************** Prototypes of Functions ***************************/

int printOriginalMatrix (double matrix [N][N]);
int printMatrix (double matrix [N][N]);
int printVector(double vector[N]);
int printRanking (double matrix[N][2]);

#endif /* PRINT_H */