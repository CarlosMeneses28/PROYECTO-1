/* Ruler 1         2         3         4         5         6         7        */

/*********************************  operations.c  *****************************/
/*                                                                            */
/*   Purpose: Do useful math operations for vector PageRank                   */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

/********************************** Headers ***********************************/

/* ----------------------- Inclusion of Other Headers ----------------------- */

#include "operations.h"

/*****************************  Public Functions  *****************************/

/*FN****************************************************************************
*
*   int 
*   Mxv(double matrix[N][N], double vector_iterador[N]);
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Multiply a matrix by a vector
*
*   Plan:
*           Part 1: Initialize value at cero
*           Part 2: Replace the values of the vector
*
*******************************************************************************/

int 
Mxv(double matrix[N][N], double vector_iterador[N]) {
    for (int i = 0; i < N; i++) {
      
        //Part 1
        vector_iterador[i] = 0;
        for (int j = 0; j < N; j++) {
          
            //Part 2
            vector_iterador[i] += matrix[i][j] * vector_iterador[j];
        }
    }
  return 1;
}

/*FN****************************************************************************
*
*   double 
*   sumV (double vector[])
*
*   Return:          Sum values of a vector
*
*   Purpose:         Sum values of a vector
*
*   Plan:
*           Part 1: Initialize value at cero
*           Part 2: Sum the values of the vector
*
*******************************************************************************/

double 
sumV (double vector[])
{
  //Part 1
  double sumador = 0.0;
  for (int i=0; i<N; i++){

    //Part 2
    sumador += vector[i];
  }
  return sumador;
}

