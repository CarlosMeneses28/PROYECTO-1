/* Ruler 1         2         3         4         5         6         7        */

/*******************************  ranking.c  **********************************/
/*                                                                            */
/*   Purpose: Construction of ranking                                         */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

/********************************** Headers ***********************************/

/* ----------------------- Inclusion of Other Headers ----------------------- */

#include "ranking.h"

/*****************************  Public Functions  *****************************/

/*FN****************************************************************************
*
*   int 
*   bubbleRanking (double vector_PageRank[N][2], int j, int i)
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Bubble to make the ranking
*
*   Plan:
*           Part 1: Initialize a temporal variable
*           Part 2: Swaap the values of the ranking
*
*******************************************************************************/

int 
bubbleRanking (double vector_PageRank[N][2], int j, int i)
{
  //Part 1
  double tmp;

  //Part 2
  tmp = vector_PageRank [j][i];
  vector_PageRank [j][i] = vector_PageRank [j+1][i];
  vector_PageRank [j+1][i] = tmp;
  
  return 1;
}

/*FN****************************************************************************
*
*   int 
*   ranking (double vector_iterador [N], double vector_PageRank [N][2])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Determine the euclidian distance between two vectors
*
*   Plan:
*           Part 1: Construction of the PageRank vector
*           Part 2: Ranking of the PageRank vector
*
*******************************************************************************/

int 
ranking (double vector_iterador [N], double vector_PageRank [N][2])
{
  int tmp = 0;

  //Part 1
  for (int i=0; i<N; i++)
    {
      int j=i+1;
      vector_PageRank[i][0] = j;
      vector_PageRank[i][1] = vector_iterador[i];
    }

  //Part 2  
  for (int i=0; i<N; i++)
  {
    for (int j=0; j<N-1; j++)
    {
      if (vector_PageRank [j][1] < vector_PageRank [j+1][1])
      {
        bubbleRanking (vector_PageRank,j,1);
        bubbleRanking (vector_PageRank,j,0);
      }
    }
  }
  return 1;
}