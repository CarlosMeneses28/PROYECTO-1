/* Ruler 1         2         3         4         5         6         7        */

/*********************************  matrix.h  *********************************/
/*                                                                            */
/*   Purpose: Construction of matrix                                          */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

#ifndef MATRIX_H
#define MATRIX_H
#define N 3444

/************************** Prototypes of Functions ***************************/

int readArchive (double matrix [N][N]);
double* prob (double matrix[N][N]);
int distProb (double matrix[N][N], double prob[N]);
int absorbentNode (double matrix[N][N]);
int stochasticMatrix (double matrix[N][N]);
int irreducibleMatrix (double matrix[N][N]);
int bubbleTranspose (double matrix[N][N],int i, int j);
int transposeMatrix (double matrix[N][N]);

#endif /* MATRIX_H */
