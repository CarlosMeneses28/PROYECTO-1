/* Ruler 1         2         3         4         5         6         7        */

/*****************************  PageRank.c  ***********************************/
/*                                                                            */
/*   Purpose: The function who calls all the functions                        */
/*                                                                            */
/*   Origin: Written and tested by Carlos Gabriel Meneses,                    */
/*           February 25th, 2024                                              */                        
/*                                                                            */
/*   e-mail:  carlosg_meneses@javeriana.edu.co                                */
/*                                                                            */
/******************************************************************************/

/********************************** Headers ***********************************/

/* ------------------------ Inclusion of Std Headers ------------------------ */

#include <stdio.h>

/* ----------------------- Inclusion of Other Headers ----------------------- */

#include "print.h"

/* ----------------------- Inclusion of Own Headers ----------------------- */

#include "matrix.h"
#include "print.h"
#include "powerMethod.h"
#include "ranking.h"

/*****************************  Public Functions  *****************************/

/*FN****************************************************************************
*
*   int 
*   PageRank (double matrix[N][N], double vector_iterador[N], double vector_PageRank [N][2])
*
*   Return:          Number "1" for SUCCEED
*
*   Purpose:         Execute the PageRank´s algorithm
*
*   Plan:
*           Part 1: Original matrix
*           Part 2: Probability distribution
*           Part 3: Stochastic matrix
*           Part 4: Irreducible matrix
*           Part 5: Transpose matrix
*           Part 6: Power method
*           Part 7: Ranking
*
*******************************************************************************/

int 
PageRank (double matrix[N][N], double vector_iterador[N], double vector_PageRank [N][2])
{
  //Part 1
  readArchive(matrix);

  //Part 2
  double *proba = prob (matrix);
  distProb (matrix, proba);

  //Part 3
  int absorbent = absorbentNode(matrix);
  if (absorbent!=0)
  stochasticMatrix (matrix);

  //Part 4
  irreducibleMatrix(matrix);

  //Part 5
  transposeMatrix(matrix);

  //Part 6
  powerMethod(matrix, vector_iterador);

  //Part 7
  ranking(vector_iterador,vector_PageRank);
  printf("\n\n\nRANKING:\n\n");
  printRanking(vector_PageRank);
  return 1;
}