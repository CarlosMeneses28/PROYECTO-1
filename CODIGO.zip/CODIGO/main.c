#include <stdio.h>
#include "PageRank.h"
#define N 3444

double matrix [N][N];

int main(void) {
  double vector_iterador[N];
  double vector_PageRank [N][2];
  PageRank(matrix, vector_iterador, vector_PageRank);
  return 0;
}